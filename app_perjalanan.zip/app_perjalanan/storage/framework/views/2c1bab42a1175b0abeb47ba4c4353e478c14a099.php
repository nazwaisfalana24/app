<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
          <div class="card mb-4">
            <div class="card-header pb-0">
              <h6>Peduli Diri</h6>
              <a class="btn btn-success btn-sm ms-auto" href="/kota/create"> Tambah Data </a>
            </div>
            <div class="card-body px-0 pt-0 pb-2">
              <div class="table-responsive p-0">
                <table class="table align-items-center mb-0">
                  <thead>
                    <tr>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">No</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Nama Kota</th>
                      <th class="text-secondary opacity-7"></th>
                    </tr>
                  </thead>
                  <?php $__currentLoopData = $kota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tbody>
                    <tr>
                        <td class="align-middle text-center text-sm"><?php echo e($i+1); ?></td>
                        <td class="align-middle text-center text-sm"><?php echo e($a->nama_kota); ?></td>
                    </tr>
                  </tbody>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
              </div>
            </div>
          </div>
        </div>
    </div>
</div>

<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Kota</title>
</head>
<body>
    <center>
        <h2> Kota </h2>
    <table border="1">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Kota</th>
                <th>Tanggal Berangkat</th>
                <th>Waktu</th>
            </tr>
        </thead>
        <?php $__currentLoopData = $kota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
            <tr>
                <td><?php echo e($i+1); ?></td>
                <td><?php echo e($a->nama_kota); ?></td>
                <td><?php echo e($a->tanggal); ?></td>
                <td><?php echo e($a->waktu); ?></td}>
            
            </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <a href="/kota/create"> Tambah Data </a>
</body>
</html> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app_perjalanan\resources\views/kota/index.blade.php ENDPATH**/ ?>