<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
          <div class="card mb-4">
            <div class="card-header pb-0">
              <div>
              <h6>Peduli Diri</h6>
              <!-- <a class="btn btn-success btn-sm ms-auto" href="/user/create"> Tambah Data </a> -->
            </div>
            <div>
            <div class="card-body px-0 pt-0 pb-2">
              <div class="table-responsive p-0">
                <table class="table align-items-center mb-0">
                  <thead>
                    <tr>
                      <th class="text-center  text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">No</th>
                      <th class="text-center  text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">NIK</th>
                      <th class="text-center  text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Nama</th>
                      <th class="text-center  text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Email</th>
                      <th class="text-center  text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">No Telp</th>
                      <th class="text-center  text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Kota</th>
                      <th class="text-center  text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Username</th>
                      <th class="text-center  text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Password</th>
                      <th class="text-center  text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Foto</th>
                      <th class="text-center  text-secondary opacity-7"></th>
                    </tr>
                  </thead>
                  <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tbody>
                    <tr>
                        <td class="align-middle text-center text-sm"><?php echo e($loop->iteration); ?></td>
                        <td class="align-middle text-center text-sm"><?php echo e($a->nik); ?></td>
                        <td class="align-middle text-center text-sm"><?php echo e($a->nama); ?></td>
                        <td class="align-middle text-center text-sm"><?php echo e($a->email); ?></td>
                        <td class="align-middle text-center text-sm"><?php echo e($a->telp); ?></td>
                        <?php if($a->id_kota == NULL): ?>
                          <td class="align-middle text-center text-sm"></td>
                        <?php else: ?>  
                          <td class="align-middle text-center text-sm"><?php echo e($a->kota->nama_kota); ?></td>
                        <?php endif; ?>
                        <td class="align-middle text-center text-sm"><?php echo e($a->username); ?></td>
                        <td class="align-middle text-center text-sm"><?php echo e($a->password); ?></td>
                        <td class="align-middle text-center text-sm"><img width="150px" src="<?php echo e(url('storage/data.profil')); ?>/<?php echo e($a->foto); ?>"
                                                                      style="max-width: 50px" class="w-100 border-radius-lg shadow-sm"></td>
                        <td>
                        <a class="btn btn-link text-dark px-3 mb-0" href="/user/edit/<?php echo e($a->id); ?>"><i class="fas fa-pencil-alt text-dark me-2" aria-hidden="true"></i>Edit</a>
                        <a class="btn btn-link text-danger text-gradient px-3 mb-0" href="/user/destroy/<?php echo e($a->id); ?>"><i class="far fa-trash-alt me-2"></i>Delete</a>
                      </td>
                    </tr>
                  </tbody>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
              </div>
            </div>
          </div>
        </div>
    </div>
</div>
<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Data Pengguna</title>
</head>
<body>
    <h2 align="center"> Data Pengguna </h2>
        <table border="1" align="center">
            <thead>
                <tr>
                    <th> No </th>
                    <th> NIK </th>
                    <th> Nama </th>
                    <th> No Telp </th>
                    <th> Email </th>
                    <th> Foto </th>
                    <th> Kota </th>
                    <th> Username </th>
                    <th> Password </th>
                    <th> Confirm Password </th>
                    <th> Aksi </th>
                </tr>
            </thead>
        </tbody>
<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(++$us); ?></td>
                        <td><?php echo e($p->nik); ?></td>
                        <td><?php echo e($p->nama); ?></td>
                        <td><?php echo e($p->telp); ?></td>
                        <td><?php echo e($p->email); ?></td>
                        <td><?php echo e($p->foto); ?></td>
                        <td><?php echo e($p->id_kota); ?></td>
                        <td><?php echo e($p->username); ?></td>
                        <td><?php echo e($p->password); ?></td>
                        <td><?php echo e($p->confirm); ?></td>
                        <td><a href="user/edit/<?php echo e($p->id); ?>">Edit</a>
                            <a href="user/destroy/<?php echo e($p->id_user); ?>"> Hapus </a></td> -->

                    <!-- </tr> -->
                    <!-- <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php echo method_field('DELETE'); ?>
        </table>
        <center>
            <a href="/user/create">Tambah Data</a>
        </center>
</body>
</html> --> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app_perjalanan\resources\views/user/index.blade.php ENDPATH**/ ?>