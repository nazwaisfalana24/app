@extends('layout.app')
@section('content')
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-md-10">
        <form action="/perjalanan/store" method="post">
                @csrf
          <div class="card">
            <div class="card-header pb-0">
              <div class="d-flex align-items-center">
                <p class="mb-0">Perjalanan</p>
                <button class="btn btn-success btn-sm ms-auto">Save</button>
              </div>
            </div>
            <div class="card-body">
              <p class="text-uppercase text-sm">Data Perjalanan</p>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="example-text-input" class="form-control-label">Tanggal</label>
                    <input class="form-control" type="date" name="tanggal">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="example-text-input" class="form-control-label">Jam</label>
                    <input class="form-control" type="time" name="jam">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="example-text-input" class="form-control-label">Lokasi</label>
                    <input class="form-control" type="text" name="lokasi">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="example-text-input" class="form-control-label">Suhu Tubuh</label>
                    <input class="form-control" type="number" name="suhu_tubuh">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="example-text-input" class="form-control-label">Id User</label>
                    <select class="form-control"  name="id_user" id="id_user">
                        <option value=""></option>
                        @foreach($user as $i)
                        <option value="{{$i->id}}">{{$i->nama}}</option>
                        @endforeach
                    </select>
                  </div>
                </div>
              </div>
            </div>
        </form>
        </div>
    </div>
</div>
<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Data Perjalanan</title>
</head>
<body>
    <center>
        <h1> Perjalanan </h1>
        <form action="/perjalanan/store" method="post">
        @csrf
        <table>
            <tr>
                <td> Tanggal </td>
                <td> : <input type="date" name="tanggal"></td>
            </tr>
            <tr>
                <td> Jam </td>
                <td> : <input type="time" name="jam"></td>
            </tr>
            <tr>
                <td> Lokasi </td>
                <td> : <input type="text" name="lokasi"></td>
            </tr>
            <tr> 
                <td> Suhu Tubuh </td>
                <td> : <input type="text" name="suhu_tubuh"></td>
            </tr>
            <tr>
                <td> Id User </td>
                <td> : <input type="text" name="id_user"></td>
        </table>
        
        <br>
        <button type="submit"> Save </button>

        </form>
</body>
</html> -->
@endsection