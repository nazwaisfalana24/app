@extends('layout.app')
@section('content')
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
          <div class="card mb-4">
            <div class="card-header pb-0">
              <h6>Peduli Diri</h6>
              <a class="btn btn-success btn-sm ms-auto" href="/perjalanan/create"> Tambah Data </a>
            </div>
            <div class="card-body px-0 pt-0 pb-2">
              <div class="table-responsive p-0">
                <table class="table align-items-center mb-0">
                  <thead>
                    <tr>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">No.</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Tanggal</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Jam</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Lokasi</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Suhu Tubuh</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Id User</th>
                      <th class="text-center text-secondary opacity-7"></th>
                    </tr>
                  </thead>
                  @foreach ($perjalanan as $i => $a) 
                  <tbody>
                    <tr>
                        <td class="align-middle text-center text-sm">{{$i+1}}</td>
                        <td class="align-middle text-center text-sm">{{$a->tanggal}}</td>
                        <td class="align-middle text-center text-sm">{{$a->jam}}</td>
                        <td class="align-middle text-center text-sm">{{$a->lokasi}}</td}>
                        <td class="align-middle text-center text-sm">{{$a->suhu_tubuh}}</td}>
                        <td class="align-middle text-center text-sm">{{$a->id_user}}</td}>
                        <td>
                        <a class="btn btn-link text-dark px-3 mb-0" href="/perjalanan/edit/{{$a->id}}"><i class="fas fa-pencil-alt text-dark me-2" aria-hidden="true"></i>Edit</a>    
                        </td}>
                      </tr>
                  </tbody>
                  @endforeach
                </table>
              </div>
            </div>
          </div>
        </div>
    </div>
</div>


<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Data Perjalanan</title>
</head>
<body>
    <center>
        <h1> Tambah Data </h1>
    <table border="2">
        <thead>
             <tr>
                 <th>No</th>
                 <th>Tanggal</th>
                 <th>Jam</th>
                 <th>Lokasi</th>
                 <th>Suhu Tubuh</th>
                 <th>Id User</th>
                 <th> Aksi </th>
             </tr>
        </thead>
        @foreach($perjalanan as $u => $i)
            <tbody>
                <tr>
                    <th>{{$u+1}}</th>
                    <th>{{$i->tanggal}}</th>
                    <th>{{$i->jam}}</th>
                    <th>{{$i->lokasi}}</th>
                    <th>{{$i->suhu_tubuh}}</th>
                    <th>{{$i->id_user}}</th>
                    <th><a href="/perjalanan/edit/{{$i->id}}" class="btn btn-success"> Edit </a>
                        <a href="/perjalanan/destroy/{{$i->id}}" class="btn btn-danger"> Hapus </a>
                        <a href="/perjalanan/show/{{$i->id}}" class="btn btn-warning"> Show </a>
                </th>
            </tr>
        </tbody>
        @endforeach
    </table>
    <a href="/perjalanan/create"> Tambah Data </a>
</body>
</html> -->
@endsection