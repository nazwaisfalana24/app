@extends('layout.app')
@section('content')
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
          <div class="card mb-4">
            <div class="card-header pb-0">
              <div>
              <h6>Peduli Diri</h6>
              <!-- <a class="btn btn-success btn-sm ms-auto" href="/user/create"> Tambah Data </a> -->
            </div>
            <div>
            <div class="card-body px-0 pt-0 pb-2">
              <div class="table-responsive p-0">
                <table class="table align-items-center mb-0">
                  <thead>
                    <tr>
                      <th class="text-center  text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">No</th>
                      <th class="text-center  text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">NIK</th>
                      <th class="text-center  text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Nama</th>
                      <th class="text-center  text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Email</th>
                      <th class="text-center  text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">No Telp</th>
                      <th class="text-center  text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Kota</th>
                      <th class="text-center  text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Username</th>
                      <th class="text-center  text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Password</th>
                      <th class="text-center  text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Foto</th>
                      <th class="text-center  text-secondary opacity-7"></th>
                    </tr>
                  </thead>
                  @foreach ($user as $a)
                  <tbody>
                    <tr>
                        <td class="align-middle text-center text-sm">{{$loop->iteration}}</td>
                        <td class="align-middle text-center text-sm">{{$a->nik}}</td>
                        <td class="align-middle text-center text-sm">{{$a->nama}}</td>
                        <td class="align-middle text-center text-sm">{{$a->email}}</td>
                        <td class="align-middle text-center text-sm">{{$a->telp}}</td>
                        @if($a->id_kota == NULL)
                          <td class="align-middle text-center text-sm"></td>
                        @else  
                          <td class="align-middle text-center text-sm">{{$a->kota->nama_kota}}</td>
                        @endif
                        <td class="align-middle text-center text-sm">{{$a->username}}</td>
                        <td class="align-middle text-center text-sm">{{$a->password}}</td>
                        <td class="align-middle text-center text-sm"><img width="150px" src="{{ url('storage/data.profil')}}/{{ $a->foto }}"
                                                                      style="max-width: 50px" class="w-100 border-radius-lg shadow-sm"></td>
                        <td>
                        <a class="btn btn-link text-dark px-3 mb-0" href="/user/edit/{{$a->id}}"><i class="fas fa-pencil-alt text-dark me-2" aria-hidden="true"></i>Edit</a>
                        <a class="btn btn-link text-danger text-gradient px-3 mb-0" href="/user/destroy/{{$a->id}}"><i class="far fa-trash-alt me-2"></i>Delete</a>
                      </td>
                    </tr>
                  </tbody>
                  @endforeach
                </table>
              </div>
            </div>
          </div>
        </div>
    </div>
</div>
<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Data Pengguna</title>
</head>
<body>
    <h2 align="center"> Data Pengguna </h2>
        <table border="1" align="center">
            <thead>
                <tr>
                    <th> No </th>
                    <th> NIK </th>
                    <th> Nama </th>
                    <th> No Telp </th>
                    <th> Email </th>
                    <th> Foto </th>
                    <th> Kota </th>
                    <th> Username </th>
                    <th> Password </th>
                    <th> Confirm Password </th>
                    <th> Aksi </th>
                </tr>
            </thead>
        </tbody>
@foreach ($user as $us => $p)
                    <tr>
                        <td>{{ ++$us }}</td>
                        <td>{{ $p->nik }}</td>
                        <td>{{ $p->nama }}</td>
                        <td>{{ $p->telp }}</td>
                        <td>{{ $p->email }}</td>
                        <td>{{ $p->foto }}</td>
                        <td>{{ $p->id_kota }}</td>
                        <td>{{ $p->username }}</td>
                        <td>{{ $p->password }}</td>
                        <td>{{ $p->confirm }}</td>
                        <td><a href="user/edit/{{$p->id}}">Edit</a>
                            <a href="user/destroy/{{$p->id_user}}"> Hapus </a></td> -->

                    <!-- </tr> -->
                    <!-- @endforeach
                    @method('DELETE')
        </table>
        <center>
            <a href="/user/create">Tambah Data</a>
        </center>
</body>
</html> --> 
@endsection