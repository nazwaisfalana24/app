@extends('layout.app')
@section('content')
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-md-10">
        <form action="/user/store" method="post" enctype="multipart/form-data">
                @csrf
          <div class="card">
            <div class="card-header pb-0">
              <div class="d-flex align-items-center">
                <p class="mb-0">User</p>
                <button class="btn btn-success btn-sm ms-auto">Save</button>
              </div>
            </div>
            <div class="card-body">
              <p class="text-uppercase text-sm">User Information</p>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="example-text-input" class="form-control-label">NIK</label>
                    <input class="form-control" type="number" name="nik">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="example-text-input" class="form-control-label">Nama</label>
                    <input class="form-control" type="text" name="nama">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="example-text-input" class="form-control-label">Email</label>
                    <input class="form-control" type="text" name="email">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="example-text-input" class="form-control-label">No Telp</label>
                    <input class="form-control" type="number" name="telp">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="example-text-input" class="form-control-label">Kota</label>
                    <select class="form-control"  name="kota_id" id="kota_id">
                        <option value=""></option>
                        @foreach($kota as $i)
                        <option value="{{$i->id}}">{{ $i->nama_kota }}</option>
                        @endforeach
                    </select>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="example-text-input" class="form-control-label">Username</label>
                    <input class="form-control" type="text" name="username">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="example-text-input" class="form-control-label">Password</label>
                    <input class="form-control" type="password" name="password">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="example-text-input" class="form-control-label">Foto</label>
                    <input class="form-control" type="file" name="foto">
                  </div>
                </div>
              </div>
            </div>
        </form>
        </div>
    </div>
</div>
<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title> Create </title>
</head>
<body>
    <center>
        <form action="/user/store" method="post">
        @csrf
        <table>
            <tr>
                <td> NIK </td>
                <td> : <input type="text" name="nik"></td>
            </tr>
            <tr>
                <td> Nama </td>
                <td> : <input type="text" name="nama"></td>
            </tr>
            <tr>
                <td> No Telp </td>
                <td> : <input type="text" name="telp"> </td>
            </tr>
            <tr>
                <td> Email </td>
                <td> : <input type="text" name="email"></td>
            </tr>
            <tr>
                <td> Foto </td>
                <td> : <input type="text" name="foto"></td>
            </tr>
            <tr>
                <td> Kota </td>
                <td> : <input type="text" name="id_kota"></td>
            </tr>
            <tr>
                <td> Username </td>
                <td> : <input type="text" name="username"></td>
            </tr>
            <tr>
                <td> Password </td>
                <td> : <input type="password" name="password"></td>
            </tr>
            <tr>
                <td> Confirm Password </td>
                <td> : <input type="password" name="confirm"></td>
            </tr>
        </table>
        <br>
        <button type="submit">Save</button>
        </form>
</body>
</html> -->
@endsection