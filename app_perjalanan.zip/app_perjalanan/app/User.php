<?php

namespace App;
use App\Kota;
use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;
    
    protected $table = 'user';
    protected $primaryKey = 'id';
    protected $fillable = [
        'id',
        'nik',
        'nama',
        'email',
        'telp',
        'username', 
        'password',
        'foto',
        'id_kota',
    ];
    
    public function kota()
    {
        return $this->belongsTo(Kota::class, 'id_kota');
    }

    protected $hidden = [
        'password', 'remember_token',
    ];

  
    protected $casts = [
        'email_verified_at' => 
        'datetime',
    ];
}
