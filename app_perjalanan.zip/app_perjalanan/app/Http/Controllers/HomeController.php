<?php

namespace App\Http\Controllers;
use App\Kota;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
class HomeController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        return view('home');
    }

    public function profile()
    {
        $kota = Kota::all();
        $data = Auth::user();
        return view('profile', compact('data','kota'));
    }
}
