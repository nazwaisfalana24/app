<?php

namespace App\Http\Controllers;
use Auth;
use Illuminate\Http\Request;

 class loginController extends Controller
 {
     public function login(){
         return view('auth.login');
     }

     public function postlogin(Request $request){
        // return redirect('/dashboard');
         if(Auth::attempt($request->only('username','password'))){
            return redirect('/dashboard');
         }
         else{
             return redirect('/login');
         }
     }
     public function register(){
         return view('auth.register');
     }
     
     public function logout(){
         Auth::logout();
         return redirect ('auth.home');
        }
    }


