<?php

namespace App;

use App\User;
use Illuminate\Database\Eloquent\Model;

class Kota extends Model
{
    protected $table ='kotas';
    protected $primaryKey ='id';
    protected $fillable = [
        'nama_kota',
    ];

    public function user()
    {
        return $this->hasOne(User::class, 'id_kota');
    }
}
